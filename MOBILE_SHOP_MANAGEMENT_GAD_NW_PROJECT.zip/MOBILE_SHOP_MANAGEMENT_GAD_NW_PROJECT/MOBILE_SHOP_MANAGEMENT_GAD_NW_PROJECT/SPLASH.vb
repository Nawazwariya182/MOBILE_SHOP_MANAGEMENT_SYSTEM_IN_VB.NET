﻿Imports Microsoft.VisualBasic.Logging

Public Class SPLASH
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(3)
        ProgressBar2.Increment(3)
        If ProgressBar1.Value & ProgressBar2.Value = 100 Then
            Me.Hide()
            Dim log = New LOGIN
            log.Show()
            Timer1.Enabled = False
        End If
    End Sub

    Private Sub SPLASH_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub
End Class
